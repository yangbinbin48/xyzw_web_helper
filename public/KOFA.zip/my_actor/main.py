"""Module defines the main entry point for the Apify Actor.

Feel free to modify this file to suit your specific needs.

To build Apify Actors, utilize the Apify SDK toolkit, read more at the official documentation:
https://docs.apify.com/sdk/python
"""

from __future__ import annotations
from apify import Actor

import time
from playwright.async_api import async_playwright
from logger import logger
from state_manager import save_storage_data, generate_restore_state_script

# Note: To run this Actor locally, ensure that Playwright browsers are installed.
# Run `playwright install --with-deps` in the Actor's virtual environment to install them.
# When running on the Apify platform, these dependencies are already included
# in the Actor's Docker image.


async def main() -> None:
    """Define a main entry point for the Apify Actor.

    This coroutine is executed using `asyncio.run()`, so it must remain an asynchronous function for proper execution.
    Asynchronous execution is required for communication with Apify platform, and it also enhances performance in
    the field of web scraping significantly.
    """
    # Enter the context of the Actor.
    async with Actor:
        logger.info("=====================开始运行定时任务=====================")
        # 从 key-value store 获取状态文件
        state_file_store = await Actor.open_key_value_store(name='KOFS')
        state_file = await state_file_store.get_value('state.json')
        if state_file is None:
            logger.error("未从 KOFS store 中获取到 state.json，程序退出")
            await Actor.exit()        
        async with async_playwright() as p:
            # 启动浏览器
            logger.info("启动浏览器...")
            browser = await  p.chromium.launch(
                headless=True,
                args=["--start-maximized"]
            )

            context = await  browser.new_context(
                no_viewport=True
            )
            
            # 读取状态数据并生成恢复脚本
            restore_state_script = generate_restore_state_script(state_file)
            if restore_state_script:
                logger.info("恢复状态数据...")
                # 添加恢复脚本
                await  context.add_init_script(restore_state_script)
                logger.info("状态数据恢复完成")
            else:
                logger.info("状态文件不存在或为空，跳过恢复数据...")
            
            # 打开新页面
            page = await  context.new_page()
            
            # 访问assitant
            logger.info("访问assitant...")
            start_time = time.time()
            await  page.goto("https://assitant.pages.dev/admin/batch-daily-tasks", wait_until="networkidle")
            load_time = time.time() - start_time
            logger.info(f"页面加载时间: {load_time:.2f}秒")

            # 等待scheduledTasks函数可用
            logger.info("等待scheduledTasks函数可用...")
            try:
                await page.wait_for_function("typeof scheduledTasks === 'function'", timeout=10000)
                logger.info("scheduledTasks函数已就绪")
            except Exception as e:
                logger.info(f"等待scheduledTasks函数超时: {e}")

            # 调用页面中的scheduledTasks()函数获取定时任务
            logger.info("获取定时任务...")
            try:
                tasks = await page.evaluate("scheduledTasks()")
                logger.info("获取到的定时任务:")
                for task in tasks:
                    logger.info(f"ID: {task.get('id')}, 名称: {task.get('name')}, 类型: {task.get('runType')}, 时间: {task.get('runTime') or task.get('cronExpression')}, 状态: {'启用' if task.get('enabled') else '禁用'}")
                
                # 同步定时任务到cron-job.org
                #sync_tasks(tasks)
            except Exception as e:
                logger.info(f"获取定时任务时发生异常: {e}")
            
            # 等待定时任务执行完成，最长等待120秒
            logger.info("等待定时任务执行完成...")
            max_wait_time = 180
            check_interval = 5
            start_time = time.time()
            
            while time.time() - start_time < max_wait_time:
                try:
                    # 获取日志
                    logs = await page.evaluate("getLogs()")
                    # 检查是否包含"定时任务执行完成"字样
                    task_completed = False
                    for log in logs:
                        if isinstance(log, dict):
                            message = log.get('message', '')
                            if "定时任务执行完成" in message:
                                task_completed = True
                                break
                    # 如果检测到完成，跳出循环
                    if task_completed:
                        logger.info("检测到定时任务执行完成，结束等待")
                        break
                    # 等待5秒后再次检查
                    time.sleep(check_interval)
                except Exception as e:
                    logger.info(f"获取日志时发生异常: {e}")
                    # 发生异常后继续等待
                    time.sleep(check_interval)

            # 打印日志
            try:
                logger.info("整理并打印日志:")
                for log in logs:
                    if isinstance(log, dict):
                        time_str = log.get('time', '')
                        message = log.get('message', '')
                        logger.info(f"{time_str} {message}")
                    else:
                        # 处理非字典类型的日志
                        logger.info(f"{log}")
            except Exception as e:
                logger.info(f"获取日志时发生异常: {e}")
            
            # 手动保存localStorage和IndexedDB数据
            logger.info("保存状态到 key-value store...")
            await save_storage_data(page, None)
            logger.info("状态保存成功！")
            
            # 关闭上下文和浏览器
            await context.close()
            await browser.close()
            
            logger.info("=====================定时任务运行完成=====================")