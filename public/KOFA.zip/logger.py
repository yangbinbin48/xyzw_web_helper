import os
import logging
from datetime import datetime

# 配置日志
log_dir = "logs"
os.makedirs(log_dir, exist_ok=True)
log_file = os.path.join(log_dir, f"{datetime.now().strftime('%Y-%m-%d')}.log")

# 配置日志记录器
logger = logging.getLogger("app")
logger.setLevel(logging.INFO)

# 创建文件处理器
file_handler = logging.FileHandler(log_file, encoding='utf-8')
file_handler.setLevel(logging.INFO)

# 创建控制台处理器
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)
# 设置控制台处理器的编码为 UTF-8
import sys
if hasattr(console_handler, 'setStream'):
    console_handler.setStream(sys.stdout)
if hasattr(console_handler, 'stream') and hasattr(console_handler.stream, 'reconfigure'):
    console_handler.stream.reconfigure(encoding='utf-8')
# 对于 Python 3.10+，可以直接设置编码
if hasattr(console_handler, 'set_encoding'):
    console_handler.set_encoding('utf-8')

# 定义日志格式
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
file_handler.setFormatter(formatter)
console_handler.setFormatter(formatter)

# 添加处理器到记录器
if not logger.handlers:
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)